import React, { useState, useRef, useEffect } from 'react';
import { Link2, Sparkles, Target, ChevronDown } from 'lucide-react';
import { calculateRecoveryScore } from '../../utils/patientKpis.js';

const METRIC_COLORS = {
  steps: '#35d48d', sleep: '#8b7cf6', heartRate: '#ff5f7a', exercise: '#f59e0b',
  activeMinutes: '#38bdf8', recovery: '#14b8a6', activeCalories: '#f97316', sedentary: '#d6c62f', bloodPressure: '#a855f7',
};

const num = (v) => (Number.isFinite(Number(v)) ? Number(v) : null);
const mean = (arr) => (arr.length ? arr.reduce((s, v) => s + v, 0) / arr.length : null);
const withUnit = (value, unit) => (unit ? `${value} ${unit}` : `${value}`);

function metricConfigs(pd = {}) {
  // Coerce every goal/range through num() — some come from DECIMAL DB columns as
  // strings (e.g. "8.0"), which would otherwise fail Number.isFinite checks.
  return [
    { id: 'steps', key: 'steps', label: 'Steps', unit: '', dir: 'high', goal: num(pd.stepGoal), fmt: (v) => Math.round(v).toLocaleString() },
    { id: 'sleep', key: 'sleep', label: 'Sleep', unit: 'hrs', dir: 'high', goal: num(pd.sleepGoal), fmt: (v) => Number(v).toFixed(1) },
    { id: 'recovery', key: 'recoveryScore', label: 'Recovery', unit: '/100', dir: 'high', goal: 70, fmt: (v) => Math.round(v) },
    { id: 'heartRate', key: 'hr', label: 'Resting HR', unit: 'bpm', dir: 'range', range: [num(pd.restingHrBaselineLow), num(pd.restingHrBaselineHigh)], fmt: (v) => Math.round(v) },
    { id: 'exercise', key: 'exercise', label: 'Exercise', unit: 'min', dir: 'high', goal: num(pd.exerciseGoal), fmt: (v) => Math.round(v) },
    { id: 'activeMinutes', key: 'activeMinutes', label: 'Active Min', unit: 'min', dir: 'high', goal: num(pd.activeMinuteGoal), fmt: (v) => Math.round(v) },
    { id: 'activeCalories', key: 'activeCalories', label: 'Active Cal', unit: 'cal', dir: 'high', goal: num(pd.activeCalorieGoal), fmt: (v) => Math.round(v) },
    { id: 'sedentary', key: 'sedentaryHours', label: 'Sedentary', unit: 'hrs', dir: 'low', goal: num(pd.sedentaryLimit), fmt: (v) => Number(v).toFixed(1) },
    { id: 'bloodPressure', key: 'systolicBp', label: 'Blood Pressure', unit: 'mmHg', dir: 'low', goal: num(pd.bpSystolicTargetMax), fmt: (v) => Math.round(v) },
  ];
}

function heartRateScore(value, patientData) {
  const hr = num(value);
  if (hr == null) return null;
  const low = num(patientData.restingHrBaselineLow);
  const high = num(patientData.restingHrBaselineHigh);
  if (low != null && high != null) {
    const distance = hr < low ? low - hr : hr > high ? hr - high : 0;
    return distance === 0 ? 100 : Math.max(20, 100 - distance * 12);
  }
  return Math.max(0, Math.min(100, 100 - Math.max(0, hr - 74) * 4));
}

function seriesOf(healthLog, cfg, patientData) {
  if (cfg.id === 'recovery') {
    return healthLog
      .map((d) => ({
        value: calculateRecoveryScore({
          sleepHours: d.sleep,
          sleepConsistency: d.sleepConsistency,
          restingHeartRateScore: heartRateScore(d.hr, patientData),
          exerciseMinutes: d.exercise,
          activeMinutes: d.activeMinutes,
          age: patientData.age,
        }).score,
        date: d.recordDate || d.day,
      }))
      .filter((p) => p.value !== null);
  }

  return healthLog
    .map((d) => ({ value: num(d[cfg.key]), date: d.recordDate || d.day }))
    .filter((p) => p.value !== null);
}

function meetsGoal(value, cfg) {
  if (cfg.dir === 'high') return Number.isFinite(cfg.goal) && value >= cfg.goal;
  if (cfg.dir === 'low') return Number.isFinite(cfg.goal) && value <= cfg.goal;
  if (cfg.dir === 'range') {
    const [lo, hi] = cfg.range || [];
    return Number.isFinite(lo) && Number.isFinite(hi) && value >= lo && value <= hi;
  }
  return false;
}

function computeStats(series, cfg) {
  const values = series.map((p) => p.value);
  if (!values.length) return null;
  const last7 = values.slice(-7);
  const prev7 = values.slice(-14, -7);
  const wowNow = mean(last7);
  const wowPrev = mean(prev7);
  let max = series[0];
  let min = series[0];
  for (const p of series) {
    if (p.value > max.value) max = p;
    if (p.value < min.value) min = p;
  }
  let streak = 0;
  for (let i = series.length - 1; i >= 0; i -= 1) {
    if (meetsGoal(series[i].value, cfg)) streak += 1;
    else break;
  }
  return {
    avg: mean(values),
    max,
    min,
    hits: series.filter((p) => meetsGoal(p.value, cfg)).length,
    total: series.length,
    streak,
    wow: wowNow != null && wowPrev != null ? wowNow - wowPrev : null,
  };
}

function pearson(a, b) {
  const pairs = a.map((v, i) => [v, b[i]]).filter(([x, y]) => Number.isFinite(x) && Number.isFinite(y));
  if (pairs.length < 5) return 0;
  const ma = mean(pairs.map((p) => p[0]));
  const mb = mean(pairs.map((p) => p[1]));
  let n = 0; let da = 0; let db = 0;
  for (const [x, y] of pairs) { const dx = x - ma; const dy = y - mb; n += dx * dy; da += dx * dx; db += dy * dy; }
  const den = Math.sqrt(da * db);
  return den ? n / den : 0;
}

const CONNECTION_PAIRS = [
  { a: 'sleep', b: 'hr', neg: 'On nights you sleep more, your resting heart rate tends to be lower.', pos: 'On nights you sleep more, your resting heart rate tends to be higher.' },
  { a: 'exercise', b: 'sleep', pos: 'Days with more exercise tend to come with more sleep.', neg: 'Days with more exercise tend to come with less sleep.' },
  { a: 'sedentaryHours', b: 'steps', neg: 'The more you sit, the fewer steps you take that day.', pos: 'More sitting goes with more steps that day.' },
  { a: 'sedentaryHours', b: 'hr', pos: 'The more you sit, the higher your resting heart rate tends to be.', neg: 'More sitting goes with a lower resting heart rate.' },
  { a: 'steps', b: 'hr', neg: 'On more active days, your resting heart rate tends to be lower.', pos: 'On more active days, your resting heart rate tends to be higher.' },
];

function buildConnections(healthLog) {
  const results = [];
  for (const pair of CONNECTION_PAIRS) {
    const r = pearson(healthLog.map((d) => num(d[pair.a])), healthLog.map((d) => num(d[pair.b])));
    const abs = Math.abs(r);
    // 0.35 floor keeps out weak/coincidental links (n=30 can throw up spurious ~0.3s).
    if (abs < 0.35) continue;
    const strength = abs >= 0.6 ? 'strong' : abs >= 0.45 ? 'clear' : 'mild';
    results.push({ text: r < 0 ? pair.neg : pair.pos, r, strength });
  }
  return results.sort((x, y) => Math.abs(y.r) - Math.abs(x.r)).slice(0, 3);
}

function fmtDate(d) {
  if (!d) return '';
  const date = new Date(d);
  return Number.isNaN(date.getTime()) ? String(d) : date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

function wowTone(wow, cfg) {
  if (wow == null || cfg.dir === 'range' || Math.abs(wow) < 1e-9) return null;
  const improving = cfg.dir === 'high' ? wow > 0 : wow < 0;
  return improving ? 'good' : 'bad';
}

function percentile(values, p) {
  if (!values.length) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = (sorted.length - 1) * p;
  const lo = Math.floor(idx);
  const hi = Math.ceil(idx);
  return lo === hi ? sorted[lo] : sorted[lo] + (sorted[hi] - sorted[lo]) * (idx - lo);
}

// Round a suggested goal to a tidy, metric-appropriate increment.
const NICE_STEP = { steps: 100, activeCalories: 25, sleep: 0.1, sedentary: 0.1 };
function roundNice(value, id) {
  const step = NICE_STEP[id] || 1;
  return Math.round(value / step) * step;
}

// Suggest a goal grounded in the patient's own recent data instead of an
// arbitrary number: the level they already reach on their stronger days
// (75th percentile for "higher is better", 25th for "lower is better").
// Skips clinical metrics (heart rate range, blood pressure), which shouldn't be
// self-adjusted from personal readings.
function goalSuggestion(series, stats, cfg) {
  const coachable = cfg.dir === 'high' || cfg.id === 'sedentary';
  if (!coachable || !stats || series.length < 7) return null;

  const values = series.map((p) => p.value);
  const raw = cfg.dir === 'low' ? percentile(values, 0.25) : percentile(values, 0.75);
  const shown = withUnit(cfg.fmt(roundNice(raw, cfg.id)), cfg.unit).trim();
  const hitRate = stats.total ? stats.hits / stats.total : 0;
  const hasGoal = Number.isFinite(cfg.goal);
  const noun = cfg.dir === 'low' ? 'limit' : 'target';

  let text;
  if (!hasGoal) {
    text = `No ${noun} set yet. Based on your last 30 days, about ${shown} would be a realistic ${noun}.`;
  } else if (hitRate < 0.2) {
    text = cfg.dir === 'low'
      ? `You're over your limit most days (under it ${stats.hits} of ${stats.total}). Aim for about ${shown} as a first step — you manage that on your better days.`
      : `You're meeting this goal on only ${stats.hits} of ${stats.total} days. A more reachable target is about ${shown} — you already hit that on your stronger days.`;
  } else if (hitRate > 0.85) {
    text = cfg.dir === 'low'
      ? `You're under your limit ${stats.hits} of ${stats.total} days — you could tighten it to about ${shown}.`
      : `You're hitting this goal ${stats.hits} of ${stats.total} days. For a new challenge, aim for about ${shown}.`;
  } else {
    text = `Based on your last 30 days, a realistic ${noun} is about ${shown}.`;
  }
  return { text, value: shown, noun };
}

export function HealthSummary({ healthLog = [], patientData = {}, initialMetricId = null }) {
  const configs = metricConfigs(patientData);
  const validInitial = configs.some((c) => c.id === initialMetricId) ? initialMetricId : 'steps';
  const [selectedId, setSelectedId] = useState(validInitial);
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef(null);

  // Close the metric dropdown when clicking outside it.
  useEffect(() => {
    if (!menuOpen) return undefined;
    const onDown = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) setMenuOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, [menuOpen]);

  const cfg = configs.find((c) => c.id === selectedId) || configs[0];
  const series = seriesOf(healthLog, cfg, patientData);
  const stats = computeStats(series, cfg);
  const suggestion = goalSuggestion(series, stats, cfg);
  const connections = buildConnections(healthLog);
  const color = METRIC_COLORS[cfg.id];
  const latest = series.length ? series[series.length - 1].value : null;

  const goalLabel = cfg.dir === 'range'
    ? (cfg.range && Number.isFinite(cfg.range[0]) ? `target ${cfg.range[0]}-${cfg.range[1]} ${cfg.unit}` : 'no target set')
    : Number.isFinite(cfg.goal) ? `${cfg.dir === 'low' ? 'limit' : 'goal'} ${withUnit(cfg.fmt(cfg.goal), cfg.unit)}` : 'no goal set';

  return (
    <div className="mobile-flow">
      <div className="mobile-section-title">
        <div>
          <span>Last 30 days</span>
          <h2>Breakdown</h2>
        </div>
      </div>

      <div className="breakdown-select" ref={menuRef}>
        <button
          type="button"
          className={menuOpen ? 'breakdown-select-trigger open' : 'breakdown-select-trigger'}
          style={{ '--tab-color': color }}
          onClick={() => setMenuOpen((open) => !open)}
          aria-haspopup="listbox"
          aria-expanded={menuOpen}
        >
          <span className="breakdown-select-dot" />
          <span className="breakdown-select-label">{cfg.label}</span>
          <ChevronDown size={16} className="breakdown-select-chevron" />
        </button>
        {menuOpen && (
          <ul className="breakdown-select-menu" role="listbox">
            {configs.map((c) => (
              <li key={c.id} role="option" aria-selected={c.id === selectedId}>
                <button
                  type="button"
                  className={c.id === selectedId ? 'breakdown-select-option selected' : 'breakdown-select-option'}
                  style={{ '--tab-color': METRIC_COLORS[c.id] }}
                  onClick={() => { setSelectedId(c.id); setMenuOpen(false); }}
                >
                  <span className="breakdown-select-dot" />
                  {c.label}
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <section className="metric-detail-panel" style={{ '--metric-color': color }}>
        <div className="metric-detail-header">
          <div>
            <span>{goalLabel}</span>
            <h3>{cfg.label}</h3>
          </div>
          <strong>{latest != null ? cfg.fmt(latest) : '--'} <small>{cfg.unit}</small></strong>
        </div>

        <TrendChart
          series={series}
          color={color}
          goal={cfg.dir === 'range' ? undefined : cfg.goal}
          unit={cfg.unit}
          fmt={cfg.fmt}
        />

        {stats ? (
          <div className="breakdown-stats">
            <Stat label="30-day average" value={withUnit(cfg.fmt(stats.avg), cfg.unit)} />
            <Stat label="Highest" value={withUnit(cfg.fmt(stats.max.value), cfg.unit)} sub={fmtDate(stats.max.date)} />
            <Stat label="Lowest" value={withUnit(cfg.fmt(stats.min.value), cfg.unit)} sub={fmtDate(stats.min.date)} />
            <Stat label={cfg.dir === 'low' ? 'Under limit' : cfg.dir === 'range' ? 'In range' : 'Goal met'} value={`${stats.hits} of ${stats.total} days`} />
            <Stat label="Current streak" value={`${stats.streak} ${stats.streak === 1 ? 'day' : 'days'}`} />
            <Stat
              label="vs last week"
              value={stats.wow == null ? 'n/a' : `${stats.wow > 0 ? '+' : ''}${cfg.fmt(stats.wow)} ${cfg.unit}`.trim()}
              tone={wowTone(stats.wow, cfg)}
            />
          </div>
        ) : (
          <p className="breakdown-empty">Not enough history for this metric yet.</p>
        )}

        {suggestion && (
          <div className="breakdown-suggestion">
            <Target size={16} />
            <div>
              <strong>Suggested {suggestion.noun}: {suggestion.value}</strong>
              <p>{suggestion.text}</p>
            </div>
          </div>
        )}
      </section>

      <div className="mobile-section-title">
        <div>
          <span>Patterns across your metrics</span>
          <h2>Connections</h2>
        </div>
        <Link2 size={18} />
      </div>

      <section className="breakdown-connections">
        {connections.length ? (
          connections.map((c, i) => (
            <div className="connection-item" key={i}>
              <Sparkles size={15} />
              <p>{c.text}</p>
              <em className={`connection-strength ${c.strength}`}>{c.strength} link</em>
            </div>
          ))
        ) : (
          <div className="connection-item">
            <p>No clear pattern between your metrics yet — keep logging daily and check back.</p>
          </div>
        )}
      </section>
    </div>
  );
}

function Stat({ label, value, sub, tone }) {
  return (
    <div className="breakdown-stat">
      <span>{label}</span>
      <strong className={tone ? `tone-${tone}` : ''}>{value}</strong>
      {sub ? <small>{sub}</small> : null}
    </div>
  );
}

function TrendChart({ series, color, goal, unit, fmt }) {
  const [hover, setHover] = useState(null);
  if (series.length < 2) return <div className="breakdown-chart-empty">Not enough history yet</div>;

  const values = series.map((p) => p.value);
  let lo = Math.min(...values);
  let hi = Math.max(...values);
  if (Number.isFinite(goal)) { lo = Math.min(lo, goal); hi = Math.max(hi, goal); }
  const range = (hi - lo) || 1;

  const xPct = (i) => (i / (series.length - 1)) * 100;
  const yPct = (v) => 5 + (1 - (v - lo) / range) * 90; // inset to keep points off the edges

  const linePoints = series.map((p, i) => `${xPct(i)},${yPct(p.value)}`).join(' ');
  const goalY = Number.isFinite(goal) ? yPct(goal) : null;

  const yTicks = [hi, (hi + lo) / 2, lo];
  const last = series.length - 1;
  const xTicks = [0, Math.round(last / 3), Math.round((2 * last) / 3), last]
    .filter((v, i, a) => a.indexOf(v) === i)
    .map((i) => series[i].date);

  return (
    <div className="trend-chart">
      <div className="trend-y-axis">
        {yTicks.map((t, i) => <span key={i}>{fmt(t)}</span>)}
      </div>
      <div className="trend-plot">
        <svg className="trend-svg" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
          {goalY != null && <line x1="0" x2="100" y1={goalY} y2={goalY} className="trend-goal-line" />}
          <polyline points={linePoints} fill="none" stroke={color} strokeWidth="2" vectorEffect="non-scaling-stroke" strokeLinejoin="round" strokeLinecap="round" />
        </svg>
        {series.map((p, i) => (
          <button
            key={i}
            type="button"
            className={hover === i ? 'trend-dot active' : 'trend-dot'}
            style={{ left: `${xPct(i)}%`, top: `${yPct(p.value)}%`, '--dot-color': color }}
            onMouseEnter={() => setHover(i)}
            onMouseLeave={() => setHover(null)}
            onFocus={() => setHover(i)}
            onBlur={() => setHover(null)}
            aria-label={`${fmt(p.value)} ${unit} on ${fmtDate(p.date)}`}
          />
        ))}
        {hover != null && (
          <div
            className="trend-tooltip"
            style={{
              left: `${xPct(hover)}%`,
              top: `${yPct(series[hover].value)}%`,
              transform: `translate(${xPct(hover) < 20 ? '-8%' : xPct(hover) > 80 ? '-92%' : '-50%'}, calc(-100% - 10px))`,
            }}
          >
            <strong>{fmt(series[hover].value)}{unit ? ` ${unit}` : ''}</strong>
            <span>{fmtDate(series[hover].date)}</span>
          </div>
        )}
      </div>
      <div className="trend-x-axis">
        {xTicks.map((d, i) => <span key={i}>{fmtDate(d)}</span>)}
      </div>
    </div>
  );
}
