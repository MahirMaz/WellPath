const bedtimes = ['22:50:00', '23:15:00', '22:45:00', '23:05:00', '23:30:00', '22:40:00', '23:00:00'];
const wakeTimes = ['05:55:00', '06:10:00', '05:50:00', '06:05:00', '06:35:00', '05:45:00', '06:15:00'];

export const deriveKpiPlaceholderFields = (metric, dayIndex = 0, patientId = 1) => {
  const activeMinutes = Number(metric.active_minutes ?? metric.active ?? 0);
  const exerciseMinutes = Number(metric.exercise_minutes ?? metric.exercise ?? 0);
  const sleepHours = Number(metric.sleep_hours ?? metric.sleep ?? 0);
  const sedentaryHours = Number(metric.sedentary_hours ?? metric.sedentary ?? 0);
  const workoutCount = Number(metric.workout_count ?? metric.workout ?? 0);
  const stressLevel = Number(metric.stress_level ?? metric.stress ?? 5);
  const offset = (patientId + dayIndex) % bedtimes.length;

  const activeCalories = Math.max(
    180,
    Math.round(activeMinutes * 7.5 + exerciseMinutes * 4.5 + workoutCount * 28)
  );
  const sleepInterruptions = Math.max(
    0,
    Math.min(4, (sleepHours < 6 ? 2 : sleepHours < 6.6 ? 1 : 0) + (stressLevel >= 6 ? 1 : 0))
  );
  const sleepConsistency = clamp(
    round(100 - Math.abs(sleepHours - 7.5) * 12 - sleepInterruptions * 8 - Math.abs(offset - 3) * 2, 1),
    35,
    100
  );
  const longestInactiveMinutes = Math.max(
    60,
    Math.min(240, Math.round(sedentaryHours * 22 + Math.max(0, 50 - activeMinutes) * 1.5))
  );
  const workoutIntensity =
    exerciseMinutes >= 55 && activeMinutes >= 55 ? 'Vigorous' :
    exerciseMinutes >= 35 ? 'Moderate' :
    exerciseMinutes > 0 ? 'Light' :
    'None';

  return {
    active_calories: activeCalories,
    sleep_bedtime: bedtimes[offset],
    sleep_wake_time: wakeTimes[offset],
    sleep_interruptions: sleepInterruptions,
    sleep_consistency: sleepConsistency,
    longest_inactive_minutes: longestInactiveMinutes,
    workout_intensity: workoutIntensity,
  };
};

// Small deterministic PRNG so re-seeding always produces the same data.
function mulberry32(seed) {
  return function () {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const round = (value, digits = 0) => {
  const factor = 10 ** digits;
  return Math.round(value * factor) / factor;
};
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

export const generateDailyHealthData = () => {
  const data = [];

  // 30 consecutive days ending 2026-06-30.
  const endDate = new Date('2026-06-30T00:00:00Z');
  const days = [];
  for (let i = 29; i >= 0; i -= 1) {
    const d = new Date(endDate);
    d.setUTCDate(d.getUTCDate() - i);
    days.push(d.toISOString().slice(0, 10));
  }

  // Each patient has a distinct baseline "character" so profiles differ clearly.
  // Alex (1) is healthy and consistent; Maria (2) is deliberately unhealthy with
  // two standout problems for testing AI detection: severe sleep deprivation
  // (~4.8 hrs) and hypertension / elevated resting heart rate.
  const patientBaselines = {
    1: { steps: 9400, sleep: 7.4, hr: 66, exercise: 55, bp_sys: 116, bp_dia: 75, bmi: 23.0, calories: 2500, active: 60, workout: 4, diet: 8, stress: 3, sedentary: 5.0 },   // Alex  - healthy, consistent
    2: { steps: 4200, sleep: 4.8, hr: 85, exercise: 12, bp_sys: 142, bp_dia: 93, bmi: 28.9, calories: 1820, active: 16, workout: 1, diet: 4, stress: 8, sedentary: 10.5 },  // Maria - sleep-deprived, high BP/HR, sedentary
    3: { steps: 6800, sleep: 6.6, hr: 72, exercise: 30, bp_sys: 126, bp_dia: 80, bmi: 25.4, calories: 2150, active: 35, workout: 2, diet: 6, stress: 5, sedentary: 7.5 },   // James - activity drop
    4: { steps: 9000, sleep: 7.1, hr: 68, exercise: 65, bp_sys: 120, bp_dia: 78, bmi: 24.2, calories: 2400, active: 62, workout: 4, diet: 8, stress: 4, sedentary: 5.5 },   // Sophie- strong exerciser
    5: { steps: 7800, sleep: 7.0, hr: 70, exercise: 45, bp_sys: 122, bp_dia: 79, bmi: 24.8, calories: 2250, active: 48, workout: 3, diet: 7, stress: 4, sedentary: 6.0 },   // Daniel- balanced
  };

  let id = 1;
  Object.keys(patientBaselines).forEach((key) => {
    const patientId = Number(key);
    const b = patientBaselines[patientId];
    const rnd = mulberry32(patientId * 9973 + 12345);
    // Roughly-normal noise centered on 0, about [-1.5, 1.5]. Each metric draws
    // its own noise so metrics vary independently (realistic correlations).
    const noise = () => rnd() + rnd() + rnd() - 1.5;

    days.forEach((date, index) => {
      // Independent daily drivers (each draws its own noise).
      const exercise = Math.max(0, Math.round(b.exercise + noise() * 10));
      const activeMinutes = Math.max(0, Math.round(b.active + noise() * 10));
      const sedentary = clamp(round(b.sedentary + noise() * 1.1, 1), 1, 14);

      // Realistic, detectable relationships the "Connections" feature can find:
      // - more exercise -> a bit more sleep
      // - more sitting  -> fewer steps that day
      // - resting HR is lower with more sleep and higher with more sitting
      const sleep = clamp(round(b.sleep + 0.03 * (exercise - b.exercise) + noise() * 0.5, 1), 3.5, 9.5);
      const steps = Math.max(0, Math.round(b.steps - 420 * (sedentary - b.sedentary) + noise() * 800));
      const hr = Math.round(b.hr - 1.3 * (sleep - b.sleep) + 0.9 * (sedentary - b.sedentary) + noise() * 1.5);

      const dailyMetric = {
        daily_health_id: id++,
        patient_id: patientId,
        record_date: date,
        steps,
        sleep_hours: sleep,
        resting_heart_rate: hr,
        exercise_minutes: exercise,
        systolic_bp: Math.round(b.bp_sys + noise() * 3),
        diastolic_bp: Math.round(b.bp_dia + noise() * 2),
        bmi: round(b.bmi + noise() * 0.05, 1),
        calories_burned: Math.round(b.calories + noise() * 110),
        active_minutes: activeMinutes,
        workout_count: Math.max(0, Math.round(b.workout + noise() * 0.8)),
        diet_score: clamp(Math.round(b.diet + noise() * 1.2), 1, 10),
        stress_level: clamp(Math.round(b.stress + noise() * 1.3), 1, 10),
        sedentary_hours: sedentary,
        data_source: index % 2 === 0 ? 'wearable' : 'manual',
        created_at: new Date(),
      };

      data.push({
        ...dailyMetric,
        ...deriveKpiPlaceholderFields(dailyMetric, index, patientId),
      });
    });
  });
  return data;
};

// Daily mood (1-5) derived from that day's physiology plus noise, so the mood
// analysis has genuine signal. Mood responds to how each day deviates from the
// patient's OWN baseline (a uniformly unhealthy patient still has better and
// worse days), anchored around a personal base level set by overall health.
export const generateMoodData = (dailyHealthData) => {
  const byPatient = new Map();
  for (const day of dailyHealthData) {
    if (!byPatient.has(day.patient_id)) byPatient.set(day.patient_id, []);
    byPatient.get(day.patient_id).push(day);
  }

  const moods = [];
  for (const [patientId, days] of byPatient) {
    const avg = (key) => days.reduce((s, d) => s + Number(d[key]), 0) / days.length;
    const avgSleep = avg('sleep_hours');
    const avgActive = avg('active_minutes');
    const avgStress = avg('stress_level');
    const avgSed = avg('sedentary_hours');
    // Personal anchor: healthier overall habits -> higher typical mood.
    const base = Math.max(1.8, Math.min(4.2,
      3 + (avgSleep - 6.8) * 0.35 - (avgStress - 5) * 0.15 - (avgSed - 7) * 0.06
    ));

    for (const day of days) {
      const rnd = mulberry32(patientId * 7919 + Number(String(day.record_date).slice(-2)) * 131);
      const noise = () => rnd() + rnd() - 1;
      const raw =
        base +
        (Number(day.sleep_hours) - avgSleep) * 1.1 +
        (Number(day.active_minutes) - avgActive) * 0.025 -
        (Number(day.stress_level) - avgStress) * 0.3 -
        (Number(day.sedentary_hours) - avgSed) * 0.22 +
        noise() * 0.35;
      moods.push({
        patient_id: patientId,
        record_date: day.record_date,
        mood: Math.max(1, Math.min(5, Math.round(raw))),
      });
    }
  }
  return moods;
};

export const generateKpiValues = () => {
  const data = [];
  let id = 1;
  const patients = [1, 2, 3, 4, 5];
  const kpiTypes = [1, 2, 3, 4];
  const dates = ['2026-06-24', '2026-06-30'];
  
  patients.forEach(patientId => {
    dates.forEach(date => {
      kpiTypes.forEach(kpiTypeId => {
        let value = 0;
        let text = 'Moderate';
        const base = 65 + (patientId * 3) % 20;
        const variation = (patientId * 7 + kpiTypeId * 5 + Date.parse(date) / 86400000) % 30;
        
        switch(kpiTypeId) {
          case 1: // Health Score
            value = Math.min(100, base + variation - 10);
            text = value > 75 ? 'Good' : value > 55 ? 'Moderate' : 'Needs attention';
            break;
          case 2: // Risk Score
            value = Math.min(100, 30 + (100 - base) * 0.7 + (variation - 15) * 0.5);
            text = value > 70 ? 'High' : value > 40 ? 'Moderate' : 'Low';
            break;
          case 3: // Activity Consistency
            value = Math.min(100, 60 + (patientId * 5) % 25 + (variation - 15) * 0.6);
            text = value > 75 ? 'Consistent' : value > 50 ? 'Moderate' : 'Needs improvement';
            break;
          case 4: // Recovery Score
            value = Math.min(100, 50 + (patientId * 4) % 30 + (variation - 10) * 0.7);
            text = value > 70 ? 'Good' : value > 45 ? 'Moderate' : 'Needs attention';
            break;
        }
        
        data.push({
          kpi_value_id: id++,
          patient_id: patientId,
          kpi_type_id: kpiTypeId,
          calculation_date: date,
          numeric_value: Math.round(value),
          text_value: text
        });
      });
    });
  });
  return data;
};
