import express from 'express';
import crypto from 'crypto';
import { pool } from '../config/db.js';
import { authenticate } from '../middleware/auth.js';
import {
  generateHealthInsights,
  generateTargetedDashboardInsight,
  isCompleteInsightText,
} from '../services/aiService.js';

const router = express.Router();

// Create the insight cache table once per process (no migration framework here).
let cacheTableReady = null;
function ensureInsightCacheTable() {
  if (!cacheTableReady) {
    cacheTableReady = pool.query(`
      CREATE TABLE IF NOT EXISTS ai_insight_cache (
        patient_id INT NOT NULL,
        insight_type VARCHAR(20) NOT NULL,
        target_id VARCHAR(50) NOT NULL,
        data_hash CHAR(64) NOT NULL,
        insight_text TEXT NOT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (patient_id, insight_type, target_id)
      )
    `).catch((error) => {
      // Reset so a later request can retry table creation.
      cacheTableReady = null;
      throw error;
    });
  }
  return cacheTableReady;
}

// Hash of everything that affects the generated text. When any underlying value
// changes (including record_date rolling to a new day), the hash changes and the
// cached insight is regenerated. Otherwise we serve the cached copy for free.
// Bump INSIGHT_CACHE_VERSION whenever the prompt or model changes so old cached
// insights are invalidated and regenerated in the new style.
const INSIGHT_CACHE_VERSION = 'v4-adaptive';
function buildInsightDataHash(payload) {
  return crypto
    .createHash('sha256')
    .update(JSON.stringify({ v: INSIGHT_CACHE_VERSION, ...payload }))
    .digest('hex');
}

async function getCachedInsight(patientId, insightType, targetId, dataHash) {
  try {
    await ensureInsightCacheTable();
    const [rows] = await pool.query(
      `SELECT insight_text FROM ai_insight_cache
       WHERE patient_id = ? AND insight_type = ? AND target_id = ? AND data_hash = ?`,
      [patientId, insightType, targetId, dataHash]
    );
    return rows.length ? rows[0].insight_text : null;
  } catch (error) {
    // Cache is an optimization; never let it break insight generation.
    console.error('AI insight cache read failed:', error);
    return null;
  }
}

async function storeCachedInsight(patientId, insightType, targetId, dataHash, insightText) {
  try {
    await ensureInsightCacheTable();
    await pool.query(
      `INSERT INTO ai_insight_cache (patient_id, insight_type, target_id, data_hash, insight_text)
       VALUES (?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE data_hash = VALUES(data_hash), insight_text = VALUES(insight_text)`,
      [patientId, insightType, targetId, dataHash, insightText]
    );
  } catch (error) {
    console.error('AI insight cache write failed:', error);
  }
}

// POST /api/ai/insights
router.post('/insights', authenticate, async (req, res) => {
  try {
    const { patientId, metricId, promptId, insightType, targetId, targetTitle, targetContext } = req.body;
    
    if (!patientId) {
      return res.status(400).json({ error: 'Patient ID required' });
    }

    // Get patient profile
    const [patientRows] = await pool.query(`
      SELECT 
        pp.patient_id,
        pp.primary_focus,
        p.full_name,
        p.date_of_birth
      FROM patient_profiles pp
      JOIN user_pii p ON p.user_id = pp.user_id
      WHERE pp.patient_id = ?
    `, [patientId]);

    if (patientRows.length === 0) {
      return res.status(404).json({ error: 'Patient not found' });
    }

    const patient = patientRows[0];

    // Get latest health metrics
    const [healthRows] = await pool.query(`
      SELECT 
        f.steps,
        f.sleep_hours,
        f.sleep_bedtime,
        f.sleep_wake_time,
        f.sleep_interruptions,
        f.resting_heart_rate,
        f.exercise_minutes,
        f.active_minutes,
        f.calories_burned,
        f.active_calories,
        f.sedentary_hours,
        f.longest_inactive_minutes,
        f.workout_count,
        f.workout_intensity,
        f.systolic_bp,
        f.diastolic_bp,
        f.bmi,
        f.diet_score,
        f.stress_level,
        f.record_date,
        pref.step_goal,
        pref.sleep_goal_hours,
        pref.exercise_goal_minutes,
        pref.active_minute_goal,
        pref.sedentary_limit_hours,
        pref.active_calorie_goal,
        pref.resting_hr_baseline_low,
        pref.resting_hr_baseline_high,
        pref.bp_systolic_target_max,
        pref.bp_diastolic_target_max
      FROM patient_daily_health_fact f
      LEFT JOIN patient_metric_preferences pref ON pref.patient_id = f.patient_id
      WHERE f.patient_id = ?
      ORDER BY f.record_date DESC
      LIMIT 1
    `, [patientId]);

    // Get 7-day trends
    const [trendRows] = await pool.query(`
      SELECT 
        steps,
        sleep_hours,
        resting_heart_rate,
        exercise_minutes,
        active_minutes,
        calories_burned,
        active_calories,
        sedentary_hours,
        systolic_bp,
        diastolic_bp,
        record_date
      FROM patient_daily_health_fact
      WHERE patient_id = ?
      ORDER BY record_date DESC
      LIMIT 7
    `, [patientId]);

    // Format data for AI
    const patientData = {
      name: patient.full_name,
      ageRange: patient.date_of_birth ? calculateAgeRange(patient.date_of_birth) : 'Adult',
      primaryFocus: patient.primary_focus || 'Overall wellness',
    };

    const metrics = healthRows.map(row => ({
      steps: row.steps,
      sleep: row.sleep_hours,
      hr: row.resting_heart_rate,
      exercise: row.exercise_minutes,
      activeMinutes: row.active_minutes,
      caloriesBurned: row.calories_burned,
      activeCalories: row.active_calories,
      sedentaryHours: row.sedentary_hours,
      systolicBp: row.systolic_bp,
      diastolicBp: row.diastolic_bp,
      bmi: row.bmi,
      diet: row.diet_score,
      stress: row.stress_level,
    }));

    const trends = trendRows.map(row => ({
      steps: row.steps,
      sleep: row.sleep_hours,
      hr: row.resting_heart_rate,
      exercise: row.exercise_minutes,
      activeMinutes: row.active_minutes,
      caloriesBurned: row.calories_burned,
      activeCalories: row.active_calories,
      sedentaryHours: row.sedentary_hours,
      systolicBp: row.systolic_bp,
      diastolicBp: row.diastolic_bp,
      date: row.record_date,
    })).reverse();

    if (insightType && targetId) {
      const latestMetrics = healthRows[0] || {};
      const dataHash = buildInsightDataHash({
        patientData,
        latestMetrics,
        trends,
        insightType,
        targetId,
        targetContext,
      });

      // Serve a cached insight when the underlying data is unchanged (0 tokens).
      const cached = await getCachedInsight(patientId, insightType, targetId, dataHash);
      if (cached) {
        return res.json({
          answer: cached,
          cached: true,
          disclaimer: 'Lifestyle guidance only. Not a medical diagnosis.',
        });
      }

      const answer = await generateTargetedDashboardInsight({
        patientData,
        latestMetrics,
        trends,
        insightType,
        targetId,
        targetTitle,
        targetContext,
      });

      // Only cache real insights, never the "having trouble" fallback text.
      if (isCompleteInsightText(answer)) {
        await storeCachedInsight(patientId, insightType, targetId, dataHash, answer);
      }

      return res.json({
        answer,
        cached: false,
        disclaimer: 'Lifestyle guidance only. Not a medical diagnosis.',
      });
    }

    // Generate AI insights
    const insights = await generateHealthInsights(patientData, metrics, trends);

    // Check if we should respond with specific metric insight
    let answer = insights;
    
    if (metricId) {
        answer = insights;
    }

    res.json({
      answer: answer,
      disclaimer: 'Lifestyle guidance only. Not a medical diagnosis.',
    });

  } catch (error) {
    console.error('AI Insights error:', error);
    res.status(500).json({ 
      error: 'Failed to generate insights',
      answer: 'I\'m having trouble generating insights right now. Please try again later.',
      disclaimer: 'Lifestyle guidance only. Not a medical diagnosis.',
    });
  }
});

function calculateAgeRange(dob) {
  const birthDate = new Date(dob);
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const m = today.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  
  if (age < 18) return 'Under 18';
  if (age < 30) return '18-29';
  if (age < 45) return '30-44';
  if (age < 60) return '45-59';
  return '60+';
}

export default router;
